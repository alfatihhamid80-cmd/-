package com.example.floatingsound

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.Color

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("sound_button", MODE_PRIVATE) }
    private val pickAudio = 101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 24)
            setBackgroundColor(Color.WHITE)
        }
        val title = TextView(this).apply {
            text = "زر الصوت"
            textSize = 26f
            setTextColor(Color.BLACK)
            gravity = Gravity.CENTER
        }
        layout.addView(title, LinearLayout.LayoutParams(-1, 70))

        val info = TextView(this).apply {
            text = "اختار صوت قصير، وعدّل شكل الزر العائم، وبعدها فعّل ظهوره فوق التطبيقات."
            textSize = 16f
            setTextColor(Color.DKGRAY)
            setPadding(0, 12, 0, 22)
        }
        layout.addView(info)

        val choose = Button(this).apply {
            text = "اختيار الصوت من الموبايل"
            setOnClickListener {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "audio/*"
                }
                startActivityForResult(intent, pickAudio)
            }
        }
        layout.addView(choose, match())

        val soundName = TextView(this).apply {
            text = prefs.getString("sound_name", "لم يتم اختيار صوت بعد")
            textSize = 14f
            setPadding(4, 12, 4, 16)
            setTextColor(Color.DKGRAY)
        }
        soundName.tag = "sound_name"
        layout.addView(soundName)

        val colorLabel = TextView(this).apply { text = "لون الزر"; textSize = 17f; setTextColor(Color.BLACK) }
        layout.addView(colorLabel)
        val colors = listOf("#356AE6", "#E64A4A", "#1C9B72", "#7B4DCC", "#222222", "#F39C12")
        val colorRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        colors.forEach { hex ->
            val b = Button(this).apply {
                text = "●"
                textSize = 22f
                setTextColor(Color.parseColor(hex))
                setOnClickListener {
                    prefs.edit().putString("color", hex).apply()
                    Toast.makeText(this@MainActivity, "تم تغيير اللون", Toast.LENGTH_SHORT).show()
                    sendUpdate()
                }
            }
            colorRow.addView(b, LinearLayout.LayoutParams(0, 54, 1f))
        }
        layout.addView(colorRow)

        val sizeLabel = TextView(this).apply { text = "حجم الزر"; textSize = 17f; setTextColor(Color.BLACK); setPadding(0, 18, 0, 0) }
        layout.addView(sizeLabel)
        val size = SeekBar(this).apply {
            max = 72
            progress = (prefs.getInt("size", 64) - 48).coerceIn(0, 72)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser) { prefs.edit().putInt("size", p + 48).apply(); sendUpdate() }
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        layout.addView(size, match())

        val shape = Button(this).apply {
            text = if (prefs.getBoolean("round", true)) "شكل الزر: دائري (اضغط للتغيير)" else "شكل الزر: مربع مستدير (اضغط للتغيير)"
            setOnClickListener {
                val round = !prefs.getBoolean("round", true)
                prefs.edit().putBoolean("round", round).apply()
                text = if (round) "شكل الزر: دائري (اضغط للتغيير)" else "شكل الزر: مربع مستدير (اضغط للتغيير)"
                sendUpdate()
            }
        }
        layout.addView(shape, match())

        val start = Button(this).apply {
            text = "إظهار الزر العائم"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                    Toast.makeText(this@MainActivity, "فعّل السماح بالظهور فوق التطبيقات، ثم ارجع واضغط الزر مرة أخرى", Toast.LENGTH_LONG).show()
                } else {
                    val service = Intent(this@MainActivity, OverlayService::class.java)
                    if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(service) else startService(service)
                }
            }
        }
        layout.addView(start, match())

        val stop = Button(this).apply {
            text = "إخفاء الزر العائم"
            setOnClickListener { stopService(Intent(this@MainActivity, OverlayService::class.java)) }
        }
        layout.addView(stop, match())

        setContentView(ScrollView(this).apply { addView(layout) })
    }

    private fun match() = LinearLayout.LayoutParams(-1, 56).apply { bottomMargin = 10 }

    private fun sendUpdate() {
        sendBroadcast(Intent(OverlayService.ACTION_UPDATE).setPackage(packageName))
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickAudio && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            prefs.edit().putString("audio_uri", uri.toString())
                .putString("sound_name", uri.lastPathSegment ?: "تم اختيار الصوت").apply()
            findViewById<ScrollView>(android.R.id.content)?.let { scroll ->
                // UI text is refreshed on next app open; selection is saved immediately.
            }
            Toast.makeText(this, "تم حفظ الصوت المختار", Toast.LENGTH_SHORT).show()
        }
    }
}
