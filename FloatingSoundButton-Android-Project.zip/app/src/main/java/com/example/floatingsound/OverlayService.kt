package com.example.floatingsound

import android.app.*
import android.content.*
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.TextView

class OverlayService : Service() {
    companion object { const val ACTION_UPDATE = "com.example.floatingsound.UPDATE" }
    private var windowManager: WindowManager? = null
    private var bubble: TextView? = null
    private var player: MediaPlayer? = null
    private val prefs by lazy { getSharedPreferences("sound_button", MODE_PRIVATE) }
    private val updateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) { updateBubbleStyle() }
    }

    override fun onCreate() {
        super.onCreate()
        createNotification()
        registerReceiver(updateReceiver, IntentFilter(ACTION_UPDATE))
        showBubble()
    }

    private fun createNotification() {
        val channelId = "floating_sound_channel"
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "زر الصوت العائم", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val notification = Notification.Builder(this, channelId)
            .setContentTitle("زر الصوت يعمل")
            .setContentText("الزر العائم متاح فوق التطبيقات")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .build()
        startForeground(7, notification)
    }

    private fun showBubble() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val v = TextView(this).apply {
            text = "▶"
            textSize = 25f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            elevation = 12f
        }
        bubble = v
        updateBubbleStyle()
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                   else WindowManager.LayoutParams.TYPE_PHONE
        val size = prefs.getInt("size", 64).coerceIn(48, 120)
        val params = WindowManager.LayoutParams(size, size, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 30; y = 220
        }
        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0; var moved = false
        v.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX; downY = event.rawY
                    startX = params.x; startY = params.y; moved = false; true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downX).toInt()
                    val dy = (event.rawY - downY).toInt()
                    if (kotlin.math.abs(dx) > 8 || kotlin.math.abs(dy) > 8) moved = true
                    params.x = startX + dx; params.y = startY + dy
                    windowManager?.updateViewLayout(v, params); true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) playSelectedSound()
                    true
                }
                else -> true
            }
        }
        windowManager?.addView(v, params)
    }

    private fun updateBubbleStyle() {
        val view = bubble ?: return
        val color = try { Color.parseColor(prefs.getString("color", "#356AE6")) } catch (_: Exception) { Color.BLUE }
        val drawable = GradientDrawable().apply {
            setColor(color)
            cornerRadius = if (prefs.getBoolean("round", true)) 1000f else 24f
        }
        view.background = drawable
        val size = prefs.getInt("size", 64).coerceIn(48, 120)
        view.layoutParams?.let { lp ->
            lp.width = size; lp.height = size
            try { windowManager?.updateViewLayout(view, lp) } catch (_: Exception) {}
        }
    }

    private fun playSelectedSound() {
        val uriText = prefs.getString("audio_uri", null)
        if (uriText.isNullOrBlank()) return
        try {
            player?.release()
            player = MediaPlayer().apply {
                setDataSource(this@OverlayService, Uri.parse(uriText))
                setOnCompletionListener { it.release(); if (player === it) player = null }
                setOnErrorListener { mp, _, _ -> mp.release(); if (player === mp) player = null; true }
                prepare()
                start()
            }
        } catch (_: Exception) {
            player?.release(); player = null
        }
    }

    override fun onDestroy() {
        try { unregisterReceiver(updateReceiver) } catch (_: Exception) {}
        player?.release(); player = null
        if (bubble != null) windowManager?.removeView(bubble)
        bubble = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
